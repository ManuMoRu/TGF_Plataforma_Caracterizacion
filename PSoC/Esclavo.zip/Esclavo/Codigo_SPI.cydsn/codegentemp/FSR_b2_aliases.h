/*******************************************************************************
* File Name: FSR_b2.h  
* Version 2.20
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_FSR_b2_ALIASES_H) /* Pins FSR_b2_ALIASES_H */
#define CY_PINS_FSR_b2_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define FSR_b2_0			(FSR_b2__0__PC)
#define FSR_b2_0_PS		(FSR_b2__0__PS)
#define FSR_b2_0_PC		(FSR_b2__0__PC)
#define FSR_b2_0_DR		(FSR_b2__0__DR)
#define FSR_b2_0_SHIFT	(FSR_b2__0__SHIFT)
#define FSR_b2_0_INTR	((uint16)((uint16)0x0003u << (FSR_b2__0__SHIFT*2u)))

#define FSR_b2_INTR_ALL	 ((uint16)(FSR_b2_0_INTR))


#endif /* End Pins FSR_b2_ALIASES_H */


/* [] END OF FILE */
