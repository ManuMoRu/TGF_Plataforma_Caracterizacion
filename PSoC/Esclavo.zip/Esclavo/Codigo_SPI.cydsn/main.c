/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <stdio.h>

#define N_SENSORES 30
//#define N_R_CALIBRACION 2

//uint8 muestreo=0;
//uint64 tiempo_esclavo;
//uint8 tactel;
int timeout;


//SUBPROGRAMAS MEDICION
void DM_Strong() //Funcion para salida fuerte
{   //Pone todos los pines en salida fuerte para luego ponerle el valor deseado
    RC_1_SetDriveMode(RC_1_SetDriveMode);
    RC_2_SetDriveMode(RC_2_SetDriveMode);
    FSR_a1_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a2_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a3_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a4_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a5_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a6_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a7_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a8_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a9_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a10_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a11_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a12_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a13_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_a14_SetDriveMode(FSR_a1_DM_STRONG);
    
    
    FSR_b1_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b2_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b3_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b4_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b5_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b6_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b7_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b8_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b9_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b10_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b11_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b12_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b13_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b14_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b15_SetDriveMode(FSR_a1_DM_STRONG);
    FSR_b16_SetDriveMode(FSR_a1_DM_STRONG);
    Px_SetDriveMode(Px_DM_STRONG);
}
void cargar_condensador()
{   //Pone a 1 todos los puertos para cargar rapidamente el condensador
    RC_1_Write(1);
    RC_2_Write(2);
    FSR_a1_Write(1);
    FSR_a2_Write(1);
    FSR_a3_Write(1);
    FSR_a4_Write(1);
    FSR_a5_Write(1);
    FSR_a6_Write(1);
    FSR_a7_Write(1);
    FSR_a8_Write(1);
    FSR_a9_Write(1);
    FSR_a10_Write(1);
    FSR_a11_Write(1);
    FSR_a12_Write(1);
    FSR_a13_Write(1);
    FSR_a14_Write(1);
    
    
    FSR_b1_Write(1);
    FSR_b2_Write(1);
    FSR_b3_Write(1);
    FSR_b4_Write(1);
    FSR_b5_Write(1);
    FSR_b6_Write(1);
    FSR_b7_Write(1);
    FSR_b8_Write(1);
    FSR_b9_Write(1);
    FSR_b10_Write(1);
    FSR_b11_Write(1);
    FSR_b12_Write(1);
    FSR_b13_Write(1);
    FSR_b14_Write(1);
    FSR_b15_Write(1);
    FSR_b16_Write(1);
    Px_Write(1);
}
void DM_DIG_HIZ(int tactel) //Funcion para entrada de alta impedancia
{
    //Pone todos las resistencias en alta impedancia menos la que se va a medir
    Px_SetDriveMode(Px_DM_DIG_HIZ);
    //Se han ordenado de manera que cumplan con el protocolo y que se mapeen adecuadamente, solo se ha usado la FSR_A
    if(tactel!=1)
        //FSR_a1_SetDriveMode(FSR_a1_DM_DIG_HIZ);
        FSR_a7_SetDriveMode(FSR_a7_DM_DIG_HIZ);
    if(tactel!=2)
        //FSR_a2_SetDriveMode(FSR_a2_DM_DIG_HIZ);
        FSR_a8_SetDriveMode(FSR_a8_DM_DIG_HIZ);
    if(tactel!=3)
        FSR_a3_SetDriveMode(FSR_a3_DM_DIG_HIZ);
    if(tactel!=4)
        //FSR_a4_SetDriveMode(FSR_a4_DM_DIG_HIZ);
        FSR_a12_SetDriveMode(FSR_a12_DM_DIG_HIZ);
    if(tactel!=5)
        //FSR_a5_SetDriveMode(FSR_a5_DM_DIG_HIZ);
        FSR_a6_SetDriveMode(FSR_a6_DM_DIG_HIZ);
    if(tactel!=6)
        //FSR_a6_SetDriveMode(FSR_a6_DM_DIG_HIZ);
        FSR_a9_SetDriveMode(FSR_a9_DM_DIG_HIZ);
    if(tactel!=7)
        //FSR_a7_SetDriveMode(FSR_a7_DM_DIG_HIZ);
        FSR_a2_SetDriveMode(FSR_a2_DM_DIG_HIZ);
    if(tactel!=8)
        //FSR_a8_SetDriveMode(FSR_a8_DM_DIG_HIZ);
        FSR_a13_SetDriveMode(FSR_a13_DM_DIG_HIZ);
    if(tactel!=9)
        //FSR_a9_SetDriveMode(FSR_a9_DM_DIG_HIZ);
        FSR_a5_SetDriveMode(FSR_a5_DM_DIG_HIZ);
    if(tactel!=10)
       FSR_a10_SetDriveMode(FSR_a10_DM_DIG_HIZ);
    if(tactel!=11)
        //FSR_a11_SetDriveMode(FSR_a11_DM_DIG_HIZ);
        FSR_a1_SetDriveMode(FSR_a1_DM_DIG_HIZ);
    if(tactel!=12)
       // FSR_a12_SetDriveMode(FSR_a12_DM_DIG_HIZ);
        FSR_a14_SetDriveMode(FSR_a14_DM_DIG_HIZ);
    if(tactel!=13)
        //FSR_a13_SetDriveMode(FSR_a13_DM_DIG_HIZ);
        FSR_a4_SetDriveMode(FSR_a4_DM_DIG_HIZ);
    if(tactel!=14)
        FSR_a11_SetDriveMode(FSR_a11_DM_DIG_HIZ);
        
    if(tactel!=15)
        FSR_b1_SetDriveMode(FSR_b1_DM_DIG_HIZ);
    if(tactel!=16)
        FSR_b2_SetDriveMode(FSR_b2_DM_DIG_HIZ);
    if(tactel!=17)
       FSR_b3_SetDriveMode(FSR_b3_DM_DIG_HIZ);
    if(tactel!=18)
        FSR_b4_SetDriveMode(FSR_b4_DM_DIG_HIZ);
    if(tactel!=19)
        FSR_b5_SetDriveMode(FSR_b5_DM_DIG_HIZ);
    if(tactel!=20)
        FSR_b6_SetDriveMode(FSR_b6_DM_DIG_HIZ);
    if(tactel!=21)
       FSR_b7_SetDriveMode(FSR_b7_DM_DIG_HIZ);
    if(tactel!=22)
        FSR_b8_SetDriveMode(FSR_b8_DM_DIG_HIZ);
    if(tactel!=23)
       FSR_b9_SetDriveMode(FSR_b9_DM_DIG_HIZ);
    if(tactel!=24)
        FSR_b10_SetDriveMode(FSR_b10_DM_DIG_HIZ);
    if(tactel!=25)
       FSR_b11_SetDriveMode(FSR_b11_DM_DIG_HIZ);
    if(tactel!=26)
       FSR_b12_SetDriveMode(FSR_b12_DM_DIG_HIZ);
    if(tactel!=27)
        FSR_b13_SetDriveMode(FSR_b13_DM_DIG_HIZ);
    if(tactel!=28)
        FSR_b14_SetDriveMode(FSR_b14_DM_DIG_HIZ);
    if(tactel!=29)
        FSR_b15_SetDriveMode(FSR_b15_DM_DIG_HIZ);
    if(tactel!=30)
       FSR_b16_SetDriveMode(FSR_b16_DM_DIG_HIZ);
}
void poner_cero(int contador)
{   //Pone un 0 en el puerto que debe para realizar la descarga del condensador
    if(contador==1)
        //FSR_a1_Write(0u);
        FSR_a7_Write(0u);
    if(contador==2)
        //FSR_a2_Write(0u);
        FSR_a8_Write(0u);
    if(contador==3)
        FSR_a3_Write(0u);    
    if(contador==4)
        //FSR_a4_Write(0u);
        FSR_a12_Write(0u);
    if(contador==5)
        //FSR_a5_Write(0u);
        FSR_a6_Write(0u);
    if(contador==6)
        //FSR_a6_Write(0u);
        FSR_a9_Write(0u);
    if(contador==7)
        //FSR_a7_Write(0u);
        FSR_a2_Write(0u);
    if(contador==8)
        //FSR_a8_Write(0u);
        FSR_a13_Write(0u);
    if(contador==9)
        //FSR_a9_Write(0u);
        FSR_a5_Write(0u);
    if(contador==10)
        FSR_a10_Write(0u);
    if(contador==11)
        //FSR_a11_Write(0u);
        FSR_a1_Write(0u);
    if(contador==12)
        //FSR_a12_Write(0u);
        FSR_a14_Write(0u);
    if(contador==13)
        //FSR_a13_Write(0u);
        FSR_a4_Write(0u);
    if(contador==14)
        FSR_a11_Write(0u);
        
    if(contador==15)
        //FSR_b1_Write(0u);
        FSR_b8_Write(0u);
    if(contador==16)
        //FSR_b2_Write(0u);
        FSR_b9_Write(0u);
    if(contador==17)
        FSR_b3_Write(0u);
    if(contador==18)
        //FSR_b4_Write(0u);
        FSR_b7_Write(0u);
    if(contador==19)
        //FSR_b5_Write(0u);
        FSR_b10_Write(0u);
    if(contador==20)
        //FSR_b6_Write(0u);
        FSR_b14_Write(0u);
    if(contador==21)
        //FSR_b7_Write(0u);
        FSR_b6_Write(0u);
    if(contador==22)
        //FSR_b8_Write(0u);
        FSR_b11_Write(0u);
    if(contador==23)
        //FSR_b9_Write(0u);
        FSR_b2_Write(0u);
    if(contador==24)
        //FSR_b10_Write(0u);
        FSR_b15_Write(0u);
    if(contador==25)
        //FSR_b11_Write(0u);
        FSR_b5_Write(0u);
    if(contador==26)
        FSR_b12_Write(0u);
    if(contador==27)
        //FSR_b13_Write(0u);
        FSR_b1_Write(0u);
    if(contador==28)
        //FSR_b14_Write(0u);
        FSR_b4_Write(0u);
    if(contador==29)
        //FSR_b15_Write(0u);
        FSR_b13_Write(0u);
    if(contador==30)
        FSR_b16_Write(0u);
}




int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */
    SPIS_Start();
    timeout=30000;
    static uint16 array_prueba[30] = {
                 1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
                11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
                 21, 22, 23, 24, 25, 26, 27, 28, 29, 30
                };
    Cuenta_Descarga_Start();
    
    uint16 i=0u;
    uint16 comandoSPI=0x0000u;
    uint8 leer=0;
    uint8 enviar=0; 
    static uint16 descarga[30]; //Lectura de la resistencia
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    {
        comandoSPI=SPIS_SpiUartReadRxData();
        
        switch(comandoSPI)
        {
            case 0x0001:
                leer=1;
            break;
            case 0x0002:
                enviar=1;
            break;
        }
        if(leer==1)
        {
            leer=0;
            for(i=1;i<=N_SENSORES;i++)
            {   
               cargar_condensador();
               DM_Strong();
               //CyDelay(50);
               DM_DIG_HIZ(i);
               poner_cero(i);
               Cuenta_Descarga_Init();
               do{
                    descarga[i-1]=Cuenta_Descarga_ReadCounter();
               }while(Px_Read()==1 &&(descarga[i-1]>timeout));
            }
            //i=2;
            //SPIS_SpiUartWriteTxData(i);
        }
        if(enviar==1)
        {
            enviar=0;
            i=0;
            while(i<N_SENSORES)
            {
            CyDelayUs(10);
            SPIS_SpiUartWriteTxData(descarga[i]);
            //SPIS_SpiUartWriteTxData(array_prueba[i]);
            //SPIS_SpiUartWriteTxData(i);
            i++;
            }
            
        }
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
