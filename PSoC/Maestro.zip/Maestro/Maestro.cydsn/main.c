/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>

#define MAX_MSG_LEN 30
uint64 tiempo_micro=0;
uint64 time_cmd1=0;
uint64 time_cmd2=0;
uint64 time_cmd3=0;
uint16 delayMs;

//----------------------------------------------------------------------------------------------------------------------------------------------------------------
//SUBSPROGRAMAS PARA LA MEDICION 
//------------------------------------------------------------------------------------------------------------------------------------------------------------------
//OTROS SUBSPROGRAMAS
CY_ISR(Timer_ciclo_Handler)
{
    tiempo_micro++;
    Timer_ciclo_Init();
}
//-------------------------------------------------------------------------------------------------------------------------------------------------------------------
int main(void)
{
    //Configuracion Sistema
    CyGlobalIntEnable; /* Enable global interrupts. */
    UART_Start();
    SPIM_Start();
    Timer_ciclo_Start();
    isr_ciclo_StartEx(Timer_ciclo_Handler);
 
    
    uint16 e=0u; 
    uint16 recv[5]={0};
    static uint16 descarga[30];
    uint16 comandoSPI;
    uint32 comandoUART;
    
    uint8 finalizado=0;
    
    uint16 filas,columnas,proporcional,bits_rango;
    char matriz_tacteles[filas*columnas];
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    for(;;)
    { 
        if(tiempo_micro-time_cmd1 >= 195)
        {
            time_cmd1=tiempo_micro;
            comandoSPI=0x0001u;
            
            ss_Write(0);
            SPIM_SpiUartClearRxBuffer();
            SPIM_SpiUartClearTxBuffer();
            
            SPIM_SpiUartWriteTxData(comandoSPI);
            ss_Write(1);
            
            time_cmd2=tiempo_micro;
            time_cmd3=tiempo_micro;
            finalizado=1;
            
        }
        if(tiempo_micro-time_cmd2 >=183 && finalizado==1)
        {   
            time_cmd2= tiempo_micro;
            finalizado=0;
            comandoSPI= 0x0002u;
            
            ss_Write(0);
            SPIM_SpiUartClearRxBuffer();
            SPIM_SpiUartClearTxBuffer();
            e=0;
            while(e<=MAX_MSG_LEN)
            {
                if(!e)
                {   
                    SPIM_SpiUartWriteTxData(comandoSPI);
                    CyDelayUs(12);
                    recv[e]=SPIM_SpiUartReadRxData();
                    CyDelayUs(12);
                }
                else
                {
                    SPIM_SpiUartWriteTxData(0x0000);
                    CyDelayUs(12);
                    descarga[e-1]=SPIM_SpiUartReadRxData();
                    CyDelayUs(12);
                }
                e++;
            }
            
            ss_Write(1); 
        }
        
        comandoUART=UART_UartGetChar();
        
        switch(comandoUART)
        {
            case 'R':
            
            for(int i=0;i<MAX_MSG_LEN;i++)
            {
                UART_UartPutChar(descarga[i]>>8);
                UART_UartPutChar(descarga[i] & 0x00ff);
                
            }
            UART_UartPutString(";");
            comandoUART=0;
            break;
            case 'C':
                filas = 6;
                columnas = 4;
                proporcional = 1;
                bits_rango = 20000;

                 // Asignar la matriz táctil como string binario
                strcpy(matriz_tacteles, "011011110110100101101111");

                // Enviar valores por UART
                char buffer[256];

                 sprintf(buffer, "%s", matriz_tacteles);
                 CyDelay(10); // 1–2 ms
                 UART_UartPutString(buffer);
                 CyDelay(10); // 1–2 ms
                 UART_UartPutString("#");
                 CyDelay(10); // 1–2 ms
                 UART_UartPutChar(filas>>8);
                 UART_UartPutChar(filas & 0x00ff);
                 CyDelay(10); // 1–2 ms
                 UART_UartPutChar(columnas>>8);
                 UART_UartPutChar(columnas & 0x00ff);
                 CyDelay(10); // 1–2 ms
                 UART_UartPutChar(proporcional>>8);
                 UART_UartPutChar(proporcional & 0x00ff);
                 CyDelay(10);
                 UART_UartPutChar(bits_rango>>8);
                 UART_UartPutChar(bits_rango & 0x00ff);
                 UART_UartPutString(";");
                 comandoUART=0;
            break;
        }
    }
}

/* [] END OF FILE */
